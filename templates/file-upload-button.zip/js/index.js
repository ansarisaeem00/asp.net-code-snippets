/*
  A styled file input.
  by @ste_baker

*/