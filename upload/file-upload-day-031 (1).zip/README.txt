A Pen created at CodePen.io. You can find this one at https://codepen.io/drewvosburg/pen/GoRyPZ.

 Prompt from http://dailyui.co